package Cofre;

import java.util.ArrayList;

public class Cofrinho {
	
	// Cria o array que irá armazenar as moedas.
	ArrayList<Moeda> listaMoeda = new ArrayList<Moeda>();
	
	double valor;
	
	// Cria método que será usado no case 1.
	public void adicionar(Moeda M) {
		listaMoeda.add(M);
	}
	
	// Cria método que será usado no case 2.
	public void remover(Moeda M) {
		listaMoeda.remove(M);
	}
	
	// Cria método que será usado no case 3.
	public void listar() {
		for (Moeda M : listaMoeda) {
			System.out.println(M);
		}
	}
	
	// Cria método que será usado no case 4.
	public void totalConvertido() {
		double total = 0;
		for (Moeda M : listaMoeda) {
			total += M.converter();	
		}
		System.out.println("O valor total é de " + total + " moedas de um real");
	}
}
