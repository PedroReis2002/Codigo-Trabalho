package Cofre;

public class Euro extends Moeda {
	double valorEuro;

	public Euro(double valor, double valorEuro) {
		super(valor);
		this.valorEuro = valorEuro;
	}
	
	// Esse String toString serve para fazer um display mais fácil de ler quando o case 3 for aplicado.
	public String toString() {
		return ("O cofre possui " + valorEuro + " moedas de um euro");
	}
	
	// Esse equals serve para garantir que os valores vão ser retirados quando o case 2 for usado.
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Euro other = (Euro) obj;
		return Double.doubleToLongBits(valorEuro) == Double.doubleToLongBits(other.valorEuro);
	}

	@Override
	public void info() {
		// TODO Auto-generated method stub
		
	}

	// Retorna o valor já convertido que será mostrado no case 4.
	@Override
	public double converter() {
		return (valorEuro * 5);
	}
}
