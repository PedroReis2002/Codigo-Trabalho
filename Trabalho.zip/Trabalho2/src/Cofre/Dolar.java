package Cofre;

public class Dolar extends Moeda {
	double valorDolar;

	
	public Dolar(double valor, double valorDolar) {
		super(valor);
		this.valorDolar = valorDolar;
	}
	
	// Esse String toString serve para fazer um display mais fácil de ler quando o case 3 for aplicado.
	public String toString() {
		return ("O cofre possui " + valorDolar + " moedas de um dolar");
	}
	
	// Esse equals serve para garantir que os valores vão ser retirados quando o case 2 for usado.
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Dolar other = (Dolar) obj;
		return Double.doubleToLongBits(valorDolar) == Double.doubleToLongBits(other.valorDolar);
	}

	@Override
	public void info() {
		// TODO Auto-generated method stub
	
	}	

	// Retorna o valor já convertido que será mostrado no case 4.
	@Override
	public double converter() {
		return (valorDolar * 5);
	}

	
}
