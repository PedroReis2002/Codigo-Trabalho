package Cofre;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
	// A linha 9 chama a classe Cofrinho.
	Cofrinho cofre = new Cofrinho();

	// Uma interface amigável para o menu.
		System.out.println("-------------------------------------");
		System.out.println("| Boas vindas ao seu Cofre Digital! |");
		System.out.println("-------------------------------------");
		System.out.println("Oque você gostaria de fazer?");
		System.out.println("1 - Adicionar moeda.");
		System.out.println("2 - Remover moeda.");
		System.out.println("3 - Visualizar todo o saldo.");
		System.out.println("4 - Visualizar todo o saldo em reais.");
		System.out.println("0 - Fechar o programa");
		System.out.println("-------------------------------------");

	// Esta parte do código visa fazer o menu funcional.
		int navegacao;
		Scanner teclado = new Scanner(System.in);
		
		// navegacao serve para permitir user input.
		navegacao = teclado.nextInt();

		while(navegacao != 0) {
			
			switch (navegacao) {

				case 1:

					// Esse case irá adicionar moedas.
					int ValorInterno = 0;
					while (ValorInterno > 3 || ValorInterno <= 0) {
						System.out.println("Qual tipo de moeda você deseja adicionar?");
						System.out.println("1 - Real.");
						System.out.println("2 - Dolar.");
						System.out.println("3 - Euro.");
						System.out.println("0 - Retornar ao menu.");
						System.out.println("---------------------");
						navegacao = teclado.nextInt();
					
					double vs;
					Moeda M = null;
					// Esse if abaixo controla as opções do submenu dentro do case 1.
					if (navegacao == 1) {
						System.out.println("Insira quantas moedas de um real você deseja adicionar: ");
						vs = teclado.nextDouble();
						M = new Real(vs, vs);	
						
					} else if (navegacao == 2) {
						System.out.println("Insira quantas moedas de um dólar você deseja adicionar: ");
						vs = teclado.nextDouble();
						M = new Dolar(vs, vs);	
			
					} else if (navegacao == 3) {
						System.out.println("Insira quantas moedas de um euro você deseja adicionar: ");
						vs = teclado.nextDouble();
						M = new Euro(vs, vs);		
						
					} else break;
					
					cofre.adicionar(M);
					
				} break;
			
				case 2:
					// Este case irá remover moedas.
					int ValorInterno1 = 0;
					while (ValorInterno1 > 3 || ValorInterno1 <= 0) {
						System.out.println("Qual tipo do conjunto de moeda que você deseja remover?");
						System.out.println("1 - Real.");
						System.out.println("2 - Dolar.");
						System.out.println("3 - Euro.");
						System.out.println("0 - Retornar ao menu.");
						System.out.println("---------------------");
						navegacao = teclado.nextInt();

						double vs;
						Moeda M = null;
						// O if abaixo controla as opções do submenu dentro do case 2.
						if (navegacao == 1) {
							System.out.println("Insira quantas moedas de um real dentro do conjunto a ser removido: ");
							vs = teclado.nextDouble();
							M = new Real(vs, vs);
						} else if (navegacao == 2) {
							System.out.println("Insira quantas moedas de um dólar dentro do conjunto a ser removido: ");
							vs = teclado.nextDouble();
							M = new Dolar(vs, vs);
	
						} else if (navegacao == 2) {
							System.out.println("Insira quantas moedas de um euro dentro do conjunto a ser removido: ");
							vs = teclado.nextDouble();

						} else break;
						
						cofre.remover(M);
						
					} break;
					
				case 3:
					// Este case irá listar todo o valor dentro do sistema separando por cada vez que o case 1 foi usado.
					cofre.listar();
					break;

				case 4:
					// Este case irá listar todos os valores convertidos em reais.
					cofre.totalConvertido();
					break;

				default:
					// Este default serve para comunicar caso algum valor invalido seja enviado.
					System.out.println("Opção inválida.");				
				}

				System.out.println("-------------------------------------");
				System.out.println("| Boas vindas ao seu Cofre Digital! |");
				System.out.println("-------------------------------------");
				System.out.println("Oque você gostaria de fazer?");
				System.out.println("1 - Adicionar moeda.");
				System.out.println("2 - Remover moeda.");
				System.out.println("3 - Visualizar todo saldo.");
				System.out.println("4 - Visualizar todo o saldo em reais.");
				System.out.println("0 - Fechar o programa");
				System.out.println("-------------------------------------");
				navegacao = teclado.nextInt();

				}
		teclado.close();	
	}
}