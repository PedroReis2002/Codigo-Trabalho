package Cofre;

// A classe Moeda funciona como classe mãe para as classes Real, Dólar e Euro.
public abstract class Moeda {
	double Valor;
	
	public Moeda(double valor) {
		super();
		Valor = valor;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Moeda other = (Moeda) obj;
		return Double.doubleToLongBits(Valor) == Double.doubleToLongBits(other.Valor);
	}

	public abstract void info();
	public abstract double converter(); {
	}
		
}