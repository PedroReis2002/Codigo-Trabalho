package Cofre;

public class Real extends Moeda {
	double valorReal;

	public Real(double valor, double valorReal) {
		super(valor);
		this.valorReal = valorReal;
	}
	
	// Esse String toString serve para fazer um display mais fácil de ler quando o case 3 for aplicado.
	public String toString() {
		return ("O cofre possui " + valorReal + " moedas de um real");
	}
	
	// Esse equals serve para garantir que os valores vão ser retirados quando o case 2 for usado.
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Real other = (Real) obj;
		return Double.doubleToLongBits(valorReal) == Double.doubleToLongBits(other.valorReal);
	}

	@Override
	public void info() {
		// TODO Auto-generated method stub
		
	}
	
	// Retorna o valor já convertido que será mostrado no case 4.
	@Override
	public double converter() {
		return valorReal;
	}
	
	
}
